// image loading may be slow due to connectivity of internet please refresh if not getting displayed


// taking input value
const products = document.getElementById("inputValue").addEventListener("keyup", myfun);

// filtering the data ,taking products div and then taking main div from products div by tagName after this looping in main to get h4 tag which contains title of products , then changing the value of title in lower case and checking in if statement that is my input value and title value which is stored in textValue is greater than -1 or not (indexOf will give the numerical no ) if it greater then main div style will be flex otherwise it will be display none 

function myfun(e) {
    let value = e.target.value;
    // console.log(value)
    let filter = document.getElementById("products");
    let main = filter.getElementsByTagName("main");
    for (i = 0; i < main.length; i++) {
        let h4 = main[ i ].getElementsByTagName("h4")[ 0 ];
        let textValue = h4.textContent || h4.innerHTML;
        if (textValue.toLowerCase().indexOf(value.toLowerCase()) > -1) {
            main[ i ].style.display = "flex";
        } else {
            main[ i ].style.display = "none";
        }
    }
}


//  getting products throung API making async await because it is a promise and promise needs some time to finish its task. 
async function getData() {
    try {
        let res = await fetch(`https://dummyjson.com/products`);
        let data = await res.json();
        // console.log(data);
        // calling function to take products as arguments
        showData(data);
    } catch (error) {
        console.log('error:', error);
    }
}

// calling getData function
getData();


// function to show products on UI ......used forEach loop 
function showData(data) {
    // total products
    const total = document.getElementById("total");
    total.innerText = `Total Products : ${data.limit}`;
    // div where I am appending all the products
    let products = document.getElementById("products");
    // Iterating products and Another content
    data.products.forEach((items) => {
        // apending all the items into main div

        const Box = document.createElement("main");

        // apending all the products images 

        const img = document.createElement("img");
        img.src = items.thumbnail;
        img.loading = "lazy";
        img.alt = `${items.title}`;

        // create a div which contains discount and deal of the day

        const discountBox = document.createElement("div");
        discountBox.id = "discountBox";
        const discountPercentage = document.createElement("p");
        discountPercentage.innerText = `Up to ${items.discountPercentage} % off`;
        const ExtraInfo = document.createElement("p");
        ExtraInfo.innerText = "Deal Of The Day";
        discountBox.append(discountPercentage, ExtraInfo);

        // apending all the products title 

        const title = document.createElement("h4");
        title.innerText = items.title;

        // apending all the products rating and calling stars function

        const rating = document.createElement("span");
        rating.innerText = stars(items.rating);

        // apending all the products price 

        const price = document.createElement("p");
        price.innerText = `₹ ${items.price}`;

        // apending all the products description 

        const description = document.createElement("p");
        description.innerText = items.description;

        // apending Add to cart Button

        const AddToCartButton = document.createElement("button");
        AddToCartButton.innerText = "ADD TO CART";

        // apending all the items to Box 

        Box.append(img, discountBox, title, rating, description, price, AddToCartButton);

        // apending the Box to Main div and shown on UI 

        products.append(Box);
    });
}


// created a function of getting rating converting into star
// and converting points value (4.3) into its round value

function stars(rating) {
    // console.log(rating);
    let str = '';
    for (let i = 0; i < Math.round(rating); i++) {
        str += '⭐';
    }
    return str;
}








